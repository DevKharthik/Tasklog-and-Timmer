let button = document.getElementById('button');
let hour = document.getElementById('hour');
let minutes = document.getElementById('minutes');
let seconds = document.getElementById('seconds');
let task = document.getElementById('task');
let discription = document.getElementById('discription');
let entries = document.getElementById('entries');
let count = 0;
let flag = 0;
let bool1 = 0;
let intervalId;

button.addEventListener('click', start);
function start() {
    if (button.textContent === 'Start') {
        button.textContent = 'Stop';
        button.style.setProperty('background-color', 'red');
        intervalId = setInterval(startTimer, 1000);
    } else {
        button.textContent = 'Start';
        button.style.setProperty('background-color', 'green');
        entries.innerHTML += task.value + ' ';
        entries.innerHTML += discription.value + ' ';
        entries.innerHTML += hour.textContent.padStart(2, '0') + ':';
        entries.innerHTML += minutes.textContent.padStart(2, '0') + ':';
        entries.innerHTML += seconds.textContent.padStart(2, '0');
        count = 0;
        flag = 0;
        bool1 = 0;
        task.value = '';
        discription.value = '';
        clearInterval(intervalId);
        seconds.textContent = '00';
        minutes.textContent = '00';
        hour.textContent = '00';
    }

    function startTimer() {
        count++;
        if (count < 60) {
            seconds.textContent = count.toString().padStart(2, '0');
        } else if (count !== 60) {
            count = 0;
            seconds.textContent = '00';
            flag++;
            minutes.textContent = flag.toString().padStart(2, '0');
        } else if (flag === 60) {
            flag = 0;
            minutes.textContent = '00';
            bool1++;
            hour.textContent = bool1.toString().padStart(2, '0');
        }
    }
}
